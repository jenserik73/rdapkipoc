# ── Legg disse routes-blokkene inn i oci_apigateway_deployment "v1" → specification ──
# Plasser dem etter eksisterende "/admin/{path*}"-ruten, men FØR den avsluttende "}" i specification-blokken.
#
# OBS: /v1/chats/* rutes til chat-handler (ikke admin-handler).
#       /v1/admin/profiles/* rutes til profile-handler.
#       Eksisterende /v1/admin/{path*} matcher IKKE /admin/profiles/ siden
#       vi trenger profile-handler der – men for å unngå konflikt med wildcard-ruten
#       må /admin/profiles/{path*} defineres FØR /admin/{path*} i listen.
#       Flytt disse blokkene TIL TOPPEN av routes-listen (eller rett over /admin/{path*}).

    # ── Route: /v1/chats ─────────────────────────────────────
    routes {
      path    = "/chats"
      methods = ["GET", "POST", "OPTIONS"]

      backend {
        type        = "ORACLE_FUNCTIONS_BACKEND"
        function_id = oci_functions_function.chat_handler.id
      }

      response_policies {
        header_transformations {
          set_headers {
            items {
              name      = "Access-Control-Allow-Origin"
              values    = ["*"]
              if_exists = "OVERWRITE"
            }
            items {
              name      = "Strict-Transport-Security"
              values    = ["max-age=31536000; includeSubDomains"]
              if_exists = "OVERWRITE"
            }
          }
        }
      }
    }

    # ── Route: /v1/chats/{id} ─────────────────────────────────
    routes {
      path    = "/chats/{id}"
      methods = ["DELETE", "OPTIONS"]

      backend {
        type        = "ORACLE_FUNCTIONS_BACKEND"
        function_id = oci_functions_function.chat_handler.id
      }

      response_policies {
        header_transformations {
          set_headers {
            items {
              name      = "Access-Control-Allow-Origin"
              values    = ["*"]
              if_exists = "OVERWRITE"
            }
            items {
              name      = "Strict-Transport-Security"
              values    = ["max-age=31536000; includeSubDomains"]
              if_exists = "OVERWRITE"
            }
          }
        }
      }
    }

    # ── Route: /v1/chats/{id}/messages ────────────────────────
    routes {
      path    = "/chats/{id}/messages"
      methods = ["GET", "POST", "OPTIONS"]

      backend {
        type        = "ORACLE_FUNCTIONS_BACKEND"
        function_id = oci_functions_function.chat_handler.id
      }

      response_policies {
        header_transformations {
          set_headers {
            items {
              name      = "Access-Control-Allow-Origin"
              values    = ["*"]
              if_exists = "OVERWRITE"
            }
            items {
              name      = "Strict-Transport-Security"
              values    = ["max-age=31536000; includeSubDomains"]
              if_exists = "OVERWRITE"
            }
          }
        }
      }
    }

    # ── Route: /v1/chats/{id}/title ───────────────────────────
    routes {
      path    = "/chats/{id}/title"
      methods = ["PUT", "OPTIONS"]

      backend {
        type        = "ORACLE_FUNCTIONS_BACKEND"
        function_id = oci_functions_function.chat_handler.id
      }

      response_policies {
        header_transformations {
          set_headers {
            items {
              name      = "Access-Control-Allow-Origin"
              values    = ["*"]
              if_exists = "OVERWRITE"
            }
            items {
              name      = "Strict-Transport-Security"
              values    = ["max-age=31536000; includeSubDomains"]
              if_exists = "OVERWRITE"
            }
          }
        }
      }
    }

    # ── Route: /v1/admin/profiles/{path*} ─────────────────────
    # NB: Denne MÅ stå FØR /admin/{path*} i routes-listen!
    routes {
      path    = "/admin/profiles/{path*}"
      methods = ["GET", "PUT", "DELETE", "OPTIONS"]

      backend {
        type        = "ORACLE_FUNCTIONS_BACKEND"
        function_id = oci_functions_function.profile_handler.id
      }

      response_policies {
        header_transformations {
          set_headers {
            items {
              name      = "Access-Control-Allow-Origin"
              values    = ["*"]
              if_exists = "OVERWRITE"
            }
            items {
              name      = "Strict-Transport-Security"
              values    = ["max-age=31536000; includeSubDomains"]
              if_exists = "OVERWRITE"
            }
          }
        }
      }
    }
